#' Hello World
#'
#' `hello` says "hello" in the user-specified language. The uer i asked to give her/his name so that the hello message gets personalized.
#'
#'
#
#'
#' @param who a `character` vector of length 1 that specifies the name of the person t whom the message is addressed.
#' @param lang a `character` vector of length 1 that specifies the preferred language. Default to "EN" for English. Other possible values iclude "FR" for French, "IT" for Italian, "ED" for Spanish, or "DE" for German. Case is ignored.
#' @param LangData an optional data.frame with two columns each of mode `character`. The first column gives the language codes and the second column gives the corresponding "hello" word. Defualt to `language`.
#'
#' see `?language`
#'
#' @return a `character` vector with a personlized "hello" message.
#' @examples
#' hello("James")
#' hello("Amelia", "Es")
#'
#' @export

hello <- function(who, lang = "en",LangData = Hello::language){

  if(is.character(who) == F | length(who) > 1){
    stop("Please enter a valide name; see ?hello")
  }

  lang2 <- tolower(lang)

  if(lang2 %in% LangData[,1]){

    msg <- stringr::str_c(LangData[which(LangData == lang2), 2], ", ", who, "!")
  } else(
    msg <- stringr::str_c("Sorry, ", who, " , your language ( '", lang, "') is not available!")
  )
print(msg)
}









