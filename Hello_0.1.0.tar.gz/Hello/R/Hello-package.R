#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stringr str_c
## usethis namespace: end
NULL
